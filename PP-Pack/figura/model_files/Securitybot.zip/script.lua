for key, value in pairs(armor_model) do
  value.setEnabled(false)
end
for key, value in pairs(vanilla_model) do
    value.setEnabled(false)    
end
lastHealth = 0
timer = 0 
dead = false
local snds = {
    "AlertAlert",
    "SecurityAlert"
  }
model.Player.RightArm.setEnabled(false)
model.Player.LeftArm.setEnabled(false)
function tick()
    health = player.getHealth()
    nameplate.ENTITY.setText("Security Bot")
    nameplate.LIST.setText("Security Bot")
    nameplate.CHAT.setText("Security Bot")
    timer = timer+1
    var = math.random(#snds)
    if timer == 250 then
      sound.playCustomSound(snds[var], player.getPos(), {0.5,1})
      timer = 0
    end
    if (health == 0 and not dead) then
      sound.playCustomSound(snds[math.random(#snds)], player.getPos(), {0.5,1})
      dead = true
    else
      if health < lastHealth then
        sound.playCustomSound(snds[math.random(#snds)], player.getPos(), {0.5,1})
      else
        if health == player.getMaxHealth() then
          dead = false
        end
      end
    end
    lastHealth = health
    if player.getEquipmentItem(6).getType() ~= "minecraft:air" then
      model.MapBot.Hip.UpperHip.Chest.Neck.Skull.Hat2.setShader("Glint")
    else
      model.MapBot.Hip.UpperHip.Chest.Neck.Skull.Hat2.setShader("None")
  end
  if player.getEquipmentItem(5).getType() ~= "minecraft:air" then
    model.MapBot.Hip.UpperHip.Chest.ChestLayer.setShader("Glint")
  else
    model.MapBot.Hip.UpperHip.Chest.ChestLayer.setShader("None")
end
if player.getEquipmentItem(4).getType() ~= "minecraft:air" then
  model.MapBot.Hip.LowerBodyLayer.setShader("Glint")
else
  model.MapBot.Hip.LowerBodyLayer.setShader("None")
end
if player.getEquipmentItem(3).getType() ~= "minecraft:air" then
  model.MapBot.Hip.Wheels.setShader("Glint")
else
  model.MapBot.Hip.Wheels.setShader("None")
end
end
camera.FIRST_PERSON.setPos({0,.4,0})
camera.THIRD_PERSON.setPos({0,.4,0})
if client.isHost() then --CROSSHAIR MAGIC STARTS HERE.
    local function GUIScale()
      local scale = client.getGUIScale()
      if scale == 0 then scale = 99 end
      local size = client.getWindowSize()
      return math.max(math.min(scale, math.floor(size.x/320), math.floor(size.y/240)), 1)
    end
  
    local VECTOR_ZERO, VECTOR_CENTER = vectors.of{0}, vectors.of{0,0,2}
    local screenpos, windowpos = VECTOR_ZERO, {}
    local screensize, screenscale = client.getWindowSize(), GUIScale()
    local player_eyeh = 1.62
    local start, end_, ray
  
    function tick()
      screensize, screenscale = client.getWindowSize(), GUIScale()
      player_eyeh = player.getEyeHeight()
      client.setCrosshairEnabled(screenpos.z > 1)
      if renderer.isFirstPerson() and client.isHost() then
        model.Player.RightArm.setEnabled(true)
        model.Player.LeftArm.setEnabled(true)
      else
        model.Player.RightArm.setEnabled(false)
        model.Player.LeftArm.setEnabled(false)
      end
    end
  
    function world_render(delta)
      start = player.getPos(delta)
      start[2] = start[2] + player_eyeh
      end_ = start + player.getLookDir()*6
      ray = renderer.raycastBlocks(start, end_, "OUTLINE", "NONE")
  
      if ray then
        screenpos = vectors.worldToScreenSpace(ray.pos)
        windowpos[1], windowpos[2] =
          screenpos.x * screensize.x * 0.5 / screenscale,
          screenpos.y * screensize.y * 0.5 / screenscale
        client.setCrosshairPos(windowpos)
      elseif screenpos[1] ~= 0 then
        screenpos = VECTOR_CENTER
        client.setCrosshairPos(VECTOR_ZERO)
      end
    end
  end --CROSSHAIR MAGIC ENDS HERE.
  idleanim = animation.idle
  sprintanim = animation.sprint
  walkbackanim = animation.walkback
  function world_render()

    -- A whole bunch of variables, only change these if you know what you're doing
    idleanim.setBlendTime(.3)
    idleanim.setSpeed(0.8)
    walkbackanim.setBlendTime(.3)
    sprintanim.setBlendTime(.3)
    velocity = player.getVelocity()
    running = player.isSprinting()
    movement = (player.getLookDir().x > 0 and velocity.x > 0) or (player.getLookDir().x < 0 and velocity.x < 0) or (player.getLookDir().z > 0 and velocity.z > 0) or (player.getLookDir().z < 0 and velocity.z < 0)
    -- Idle
    if velocity.getLength() == 0 and not idleanim.isPlaying() and not otheraction then
      animation.stopAll()
      idleanim.play()
    -- Walk
    elseif velocity.getLength() > 0 and not sprintanim.isPlaying() and not running and not otheraction and movement then
      animation.stopAll()
      sprintanim.play()
    -- Walk backwards
    elseif velocity.getLength() > 0 and not walkbackanim.isPlaying() and not running and not otheraction and not (jump or jumpdown) and not movement then
      animation.stopAll()
      walkbackanim.play()
    -- Sprint
    elseif velocity.getLength() > 0 and not sprintanim.isPlaying() and running and not otheraction then
        animation.stopAll()
        sprintanim.play()
    end
  end