for key, value in pairs(vanilla_model) do
  value.setEnabled(false)
  armor_model.HELMET.setEnabled(false)
  armor_model.LEGGINGS.setEnabled(false)
  armor_model.BOOTS.setEnabled(false)
end
