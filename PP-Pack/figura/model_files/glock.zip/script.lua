vanilla_model.RIGHT_ARM.setRot(vectors.of({0,0,5}).toRad())
vanilla_model.RIGHT_SLEEVE.setRot(vectors.of({0,0,5}).toRad())

function world_render()
    local item = player.getEquipmentItem(1).getType()
    local holdingCrossbow = item =="minecraft:crossbow"
    held_item_model.RIGHT_HAND.setEnabled(not holdingCrossbow)
    model.RIGHT_ARM.setEnabled(holdingCrossbow)
    model.TORSO.guncontainer.gun.setEnabled(not holdingCrossbow)
end