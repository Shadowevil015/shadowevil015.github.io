local texture = {x = 16, y = 16}

function player_init()
    for i, v in pairs({model.portal1, model.portal2}) do
        for i2, v2 in pairs(v) do
            if string.sub(tostring(i2), 1, 1) == "p" and type(v2) == "table" then
                v2.setShader("EndPortal")
                v2.setScale({1, 0.2, 1})
            end
        end
    end
    gap_size = 10
    update_height()
end


function update_height()
    for i, v in pairs(vanilla_model) do
        if not string.match(i, "LEG") then
            v.setPos({0, gap_size*-1, 0})
        end
    end

    nameplate.ENTITY.setPos({0, gap_size/16, 0})

    model.portal1.setPos({0, 11.99, 0})
    model.portal2.setPos({0, 12-gap_size+0.05, 0})

    camera.THIRD_PERSON.setPos({0, gap_size/16, 0})
    
    armor_model.HELMET.setPos({0, -gap_size, 0})
    armor_model.CHESTPLATE.setPos({0, -gap_size, 0})
    for i, v in pairs(elytra_model) do
        v.setPos({0, -gap_size, 0})
    end
end

timer = 0
function tick()
    timer = timer + 1
end

r = math.random(1, 16) 
random_table = {}
function render(delta)
    local distance = 360/32
    local scale = 1.2
    local x = 0
    for i0, v0 in pairs({model.portal1, model.portal2}) do
        for i, v in pairs(v0) do
            if type(v) == "table" and v.getShader() == "None" then
                x = x + distance
                if random_table[i] == nil then
                    random_table[i] = {math.random(1, 64), math.random(1, 64), math.random(1, 64), math.random(1, 64)}
                end
                v.setRot({0, timer+delta+x, 0})
                v.cube.setScale({scale, scale, scale})
                local random = timer+delta+x+string.len(i)
                v.cube.setRot({
                    random+random_table[i][1],
                    random+random_table[i][2],
                    random+random_table[i][3]
                })
                v.setPos({0, math.sin((random+random_table[i][4])*0.2)*0.1, 0})
                v.setUV({((r*x)%15)/texture.x, ((r+random_table[i][1])%2)/texture.y})
            end
        end
    end
end