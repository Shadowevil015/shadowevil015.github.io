for key, value in pairs(vanilla_model) do
  value.setEnabled(false) 
end