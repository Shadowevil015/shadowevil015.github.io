for i,v in pairs(vanilla_model) do
    v.setEnabled(false)
end

camera.THIRD_PERSON.setPos({0, -1, 0})

model.T.setPos({0, 24.2, 0})
model.NO_PARENT.setPos({0, 24.2, 0})
model.MIMIC_RIGHT_ARM.setPos({0, 24.2, 0})
model.MIMIC_LEFT_ARM.setPos({0, 24.2, 0})
model.MIMIC_RIGHT_LEG.setPos({0, 24.2, 0})
model.MIMIC_LEFT_LEG.setPos({0, 24.2, 0})
model.KIRB_CROUCH.setPos({0, 22.6, 0})
model.elytraKIRB.setPos({0, 24.2, 0})
model.ARROWS.setPos({0, 24.2, 0})
model.LAhi.setPos({0, 24.2, 0})
model.RAhi.setPos({0, 24.2, 0})

nameplate.ENTITY.setPos({0, -1.2, 0})

model.T.red.setEnabled(false)
model.ARROWS.up.setEnabled(false)
model.ARROWS.down.setEnabled(false)
model.ARROWS.left.setEnabled(false)
model.ARROWS.right.setEnabled(false)
model.LAhi.setEnabled(false)
model.RAhi.setEnabled(false)

elytra_model.LEFT_WING.setEnabled(false)
elytra_model.RIGHT_WING.setEnabled(false)

default = {(0), (0)}
succUV = {(0), (18/256)}
succElytraUV = {(-36/256), (18/256)}

succ = keybind.newKey("SUCC", "G")
succAct = false
succTime = 0
succPage = 0
succDef = item_stack.createItem("minecraft:gray_dye", nil)
succFire = item_stack.createItem("minecraft:red_dye", nil)
succIce = item_stack.createItem("minecraft:light_blue_dye", nil)
network.registerPing("succChange")
action_wheel.SLOT_1.setItem(succFire)
action_wheel.SLOT_1.setTitle("Succ Change")
action_wheel.SLOT_1.setFunction(function() network.ping("succChange") end)
model.T.fire.setEnabled(false)
model.T.ice.setEnabled(false)
network.registerPing("succAction")

PeaTime = 40
Keybind = "Z"
network.registerPing("shootStar")
thing = {0, 0, 0}
shootK = keybind.newKey("Shoot Pea", Keybind)
timer = 0
Count = false

network.registerPing("singM")
singI = item_stack.createItem("minecraft:black_wool", nil)
action_wheel.SLOT_2.setItem(singI)
action_wheel.SLOT_2.setTitle("Toggle Sing Mode")
action_wheel.SLOT_2.setFunction(function() network.ping("singM") end)
toggleSing = false
iconTimer = 0

up = keybind.newKey("Up Beep", "UP")
down = keybind.newKey("Down Beep", "DOWN")
left = keybind.newKey("Left Beep", "LEFT")
right = keybind.newKey("Right Beep", "RIGHT")
network.registerPing("upBEEP")
network.registerPing("downBEEP")
network.registerPing("rightBEEP")
network.registerPing("leftBEEP")
upB = false
downB = false
leftB = false
rightB = false

network.registerPing("hiPing")
hiNoActiveIcon = item_stack.createItem("minecraft:carved_pumpkin", nil)
hiActiveIcon = item_stack.createItem("minecraft:jack_o_lantern", nil)
action_wheel.SLOT_3.setItem(hiNoActiveIcon)
action_wheel.SLOT_3.setTitle("Hi!")
action_wheel.SLOT_3.setFunction(function() network.ping("hiPing") end)
hiActive = false
hiTimer = 0
happy = {(36/256), (0)}

hRotX = 0
hRotY = 0

for i,v in pairs(armor_model) do
    v.setEnabled(false)
end

function hiPing()
    hiActive = true
    action_wheel.SLOT_3.setItem(hiActiveIcon)
end

function singM()
    if toggleSing == false then
        toggleSing = true
    else
        toggleSing = false
    end
end

function shootStar()

    model.NO_PARENT.projectile.setEnabled(true)
    Count = true
    getPos = player.getPos()
    getLookDir = player.getLookDir()

end

function succChange()

    if succPage == 0 then
        succPage = 1
        action_wheel.SLOT_1.setItem(succIce)
    elseif succPage == 1 then
        succPage = 2
        action_wheel.SLOT_1.setItem(succDef)
    elseif succPage == 2 then
        succPage = 0
        action_wheel.SLOT_1.setItem(succFire)
    end

end

function upBEEP()
    local BEEPpos = player.getPos()
    sound.playSound("minecraft:block.note_block.pling", {BEEPpos.x, BEEPpos.y, BEEPpos.z, 0.8, 1.4})
end

function downBEEP()
    local BEEPpos = player.getPos()
    sound.playSound("minecraft:block.note_block.pling", {BEEPpos.x, BEEPpos.y, BEEPpos.z, 0.8, 0.5})
end

function leftBEEP()
    local BEEPpos = player.getPos()
    sound.playSound("minecraft:block.note_block.pling", {BEEPpos.x, BEEPpos.y, BEEPpos.z, 0.8, 0.9})
end

function rightBEEP()
    local BEEPpos = player.getPos()
    sound.playSound("minecraft:block.note_block.pling", {BEEPpos.x, BEEPpos.y, BEEPpos.z, 0.8, 1.1})
end

function tick()

    headRot()
    onOff()
    helmet()
    boots()
    hiAnim()
    eHelmet()
    eBoots()

    if player.getAnimation() == "FALL_FLYING" then
        if succ.isPressed() and succAct == false then
                network.ping("succAction")
                elseif succAct == true then
                    if succ.isPressed() then 
                    
                    else
                        succAct = false
                    end
                end
                if succAct == true then
                    if hiActive == false then
                        local playerPos = player.getPos()
                        local playerLookDir = player.getLookDir()
                        succTime = succTime + 1
            
                        if succPage == 0 then
                            particle.addParticle("minecraft:cloud", {playerPos + playerLookDir*1 + vectors.of({0, -0.5, 0}), 0, 0, 0})
                        elseif succPage == 1 then
                            particle.addParticle("minecraft:flame", {playerPos + playerLookDir*1 + vectors.of({0, -0.7, 0}), 0, 0, 0})
                        elseif succPage == 2 then
                            particle.addParticle("minecraft:soul_fire_flame", {playerPos + playerLookDir*1 + vectors.of({0, -0.7, 0}), 0, 0, 0})
                        end
                    end
            end
    else
        if player.isSneaky() == false then
            if renderer.isFirstPerson() then
                model.MIMIC_RIGHT_ARM.setEnabled(false)
            else
                if hiActive == false then
                    model.MIMIC_RIGHT_ARM.setEnabled(true)
                end
            end
            if toggleSing == true then
                if succAct == true then
                    if succPage == 0 then

                    else
                        model.T.musicH.setEnabled(false)
                    end
                else
                    if player.getEquipmentItem(6).getType() == "minecraft:air" then
                        model.T.musicH.setEnabled(true)
                    else
                        model.T.musicH.setEnabled(false)
                    end
                end
                if up.isPressed() then
                    if(upB == true) then
                        network.ping("upBEEP")
                        upB = false
                        model.ARROWS.up.setEnabled(true)
                    end
                else
                    upB = true
                    model.ARROWS.up.setEnabled(false)
                end
            
                if down.isPressed() then
                    if(downB == true) then
                        network.ping("downBEEP")
                        downB = false
                        model.ARROWS.down.setEnabled(true)
                    end
                else
                    downB = true
                    model.ARROWS.down.setEnabled(false)
                end
                
                if left.isPressed() then
                    if(leftB == true) then
                        network.ping("leftBEEP")
                        leftB = false
                        model.ARROWS.left.setEnabled(true)
                    end
                else
                    leftB = true
                    model.ARROWS.left.setEnabled(false)
                end
            
                if right.isPressed() then
                    if(rightB == true) then
                        network.ping("rightBEEP")  
                        rightB = false
                        model.ARROWS.right.setEnabled(true)
                    end
                else
                    rightB = true
                    model.ARROWS.right.setEnabled(false)
                end
            else
                model.T.musicH.setEnabled(false)
            end
            if succ.isPressed() and succAct == false then

                network.ping("succAction")
                elseif succAct == true then
                    if succ.isPressed() then 
                    
                    else
                        succAct = false

                        model.T.Head.setUV(default)
                        model.T.fire.setEnabled(false)
                        model.T.ice.setEnabled(false)
                    end
                end
                if succAct == true then
                    if hiActive == false then
                        local playerPos = player.getPos()
                        local playerLookDir = player.getLookDir()
                        succTime = succTime + 1
            
                        if succPage == 0 then
                            model.T.fire.setEnabled(false)
                            model.T.ice.setEnabled(false)
                            particle.addParticle("minecraft:cloud", {playerPos + playerLookDir*1 + vectors.of({0, 0.6, 0}), 0, 0, 0})
                        elseif succPage == 1 then
                            model.T.fire.setEnabled(true)
                            model.T.ice.setEnabled(false)
                            particle.addParticle("minecraft:flame", {playerPos + playerLookDir*1 + vectors.of({0, 0.4, 0}), 0, 0, 0})
                        elseif succPage == 2 then
                            model.T.fire.setEnabled(false)
                            model.T.ice.setEnabled(true)
                            particle.addParticle("minecraft:soul_fire_flame", {playerPos + playerLookDir*1 + vectors.of({0, 0.4, 0}), 0, 0, 0})
                        end
                    end
                end
            end

        if hiActive == true then
            hiTimer = hiTimer + 1
        else
            action_wheel.SLOT_3.setItem(hiNoActiveIcon)
        end

        if hiTimer > 40 then
            hiTimer = 0
            hiActive = false
            model.T.Head.setUV(default)
        end

    end

    if player.getAirPercentage() < 0.99 then
        model.T.scuba.setEnabled(true)
    else
        model.T.scuba.setEnabled(false)
    end

    if timer == PeaTime - 1 then
        model.NO_PARENT.projectile.setEnabled(false)
    end
    if shootK.isPressed() and timer == 0 then
        if player.getAnimation() == "FALL_FLYING" then
            --nothing
        else
            if player.isSneaky() == true then
                --nothing
            else
                network.ping("shootStar")
                model.T.Head.setUV(succUV)
            end
        end
    else
        if timer < 2 and timer > 0 then
            model.T.Head.setUV(default)
        end
    end
    if Count == true then
        timer = timer + 1
        thing = getPos + getLookDir * timer + vectors.of({0, 1.625, 0})
        if timer == PeaTime then
            timer = 0
            Count = false
        end
    end
    thing2 = vectors.worldToPart(thing)
    model.NO_PARENT.projectile.setPos{thing2}

    if toggleSing == true then
        iconTimer = iconTimer + 1
        if iconTimer == 0 or iconTimer == 1 then
            singI = item_stack.createItem("minecraft:red_wool", nil)
        elseif iconTimer == 40 then
            singI = item_stack.createItem("minecraft:orange_wool", nil)
        elseif iconTimer == 80 then
            singI = item_stack.createItem("minecraft:yellow_wool", nil)
        elseif iconTimer == 120 then
            singI = item_stack.createItem("minecraft:lime_wool", nil)
        elseif iconTimer == 160 then
            singI = item_stack.createItem("minecraft:light_blue_wool", nil)
        elseif iconTimer == 200 then
            singI = item_stack.createItem("minecraft:blue_wool", nil)
        elseif iconTimer == 240 then
            singI = item_stack.createItem("minecraft:magenta_wool", nil)
        elseif iconTimer == 280 then
            singI = item_stack.createItem("minecraft:purple_wool", nil)
        elseif iconTimer == 320 then
            iconTimer = 0
        end
    else
        singI = item_stack.createItem("minecraft:black_wool", nil)
        iconTimer = 0
    end

    action_wheel.SLOT_2.setItem(singI)

end

function hiAnim()
    if player.getAnimation() == "FALL_FLYING" then

        model.RAhi.setEnabled(false)
        model.LAhi.setEnabled(false)
        
    else
        if player.isSneaky() == false then
            if hiActive == true then

                model.MIMIC_LEFT_ARM.setEnabled(false)
                model.MIMIC_RIGHT_ARM.setEnabled(false)
                model.RAhi.setEnabled(true)
                model.LAhi.setEnabled(true)
                
                local speed = 0.2
                local distance = 10
                local a = math.sin(world.getTime()*speed)*distance
            
                model.RAhi.setRot({0, 0, -a + 120})
                model.LAhi.setRot({0, 0, a - 120})

                model.T.Head.setUV(happy)
        
            else
        
                model.MIMIC_LEFT_ARM.setEnabled(true)
                model.MIMIC_RIGHT_ARM.setEnabled(true)
                model.RAhi.setEnabled(false)
                model.LAhi.setEnabled(false)
        
            end
        else

            model.RAhi.setEnabled(false)
            model.LAhi.setEnabled(false)

        end
    end  
end

function succAction()
    succAct = true
    model.T.Head.setUV(succUV)
end

function onOff()

    if player.getAnimation() == "FALL_FLYING" then

        model.T.setEnabled(false)
        model.MIMIC_RIGHT_ARM.setEnabled(false)
        model.MIMIC_LEFT_ARM.setEnabled(false)
        model.MIMIC_RIGHT_LEG.setEnabled(false)
        model.MIMIC_LEFT_LEG.setEnabled(false)
        model.elytraKIRB.setEnabled(true)

        nameplate.ENTITY.setPos({0, -0.8, 0})

        if succAct == true then
            model.elytraKIRB.Head.setUV(succElytraUV)
        else
            model.elytraKIRB.Head.setUV(default)
        end
        
    else

        if player.isSneaky() == true then
            if player.getAnimation() == "FALL_FLYING" then
                model.KIRB_CROUCH.setEnabled(false)
            else
                model.KIRB_CROUCH.setEnabled(true)
            end
        else
            model.KIRB_CROUCH.setEnabled(false)
        end

        if renderer.isFirstPerson() == true then
            model.MIMIC_RIGHT_ARM.setEnabled(false)
        elseif renderer.isFirstPerson() == false then
            model.MIMIC_RIGHT_ARM.setEnabled(true)
        end

        model.T.setEnabled(true)
        model.MIMIC_RIGHT_ARM.setEnabled(true)
        model.MIMIC_LEFT_ARM.setEnabled(true)
        model.MIMIC_RIGHT_LEG.setEnabled(true)
        model.MIMIC_LEFT_LEG.setEnabled(true)
        model.elytraKIRB.setEnabled(false)

        nameplate.ENTITY.setPos({0, -1.2, 0})

    end

    if player.isSneaky() == true then
        model.KIRB_CROUCH.setEnabled(true)
        model.T.setEnabled(false)
        model.MIMIC_RIGHT_ARM.setEnabled(false)
        model.MIMIC_LEFT_ARM.setEnabled(false)
        model.MIMIC_RIGHT_LEG.setEnabled(false)
        model.MIMIC_LEFT_LEG.setEnabled(false)
    else
        if player.getAnimation() == "FALL_FLYING" then
            model.KIRB_CROUCH.setEnabled(false)
            model.T.setEnabled(false)
            model.MIMIC_LEFT_ARM.setEnabled(false)
            model.MIMIC_RIGHT_LEG.setEnabled(false)
            model.MIMIC_LEFT_LEG.setEnabled(false)
        else
            model.KIRB_CROUCH.setEnabled(false)
            model.T.setEnabled(true)
            model.MIMIC_LEFT_ARM.setEnabled(true)
            model.MIMIC_RIGHT_LEG.setEnabled(true)
            model.MIMIC_LEFT_LEG.setEnabled(true)
        end
    end

end

function headRot()
   
    local hRot = vanilla_model.HEAD.getOriginRot()
    model.T.setRot({hRotX, hRotY, 0})

    if hRot.x < 0.5 and hRot.x > -0.5 then
        hRotX = -hRot.x*55
        model.T.setRot({hRotX, hRotY, 0})
    end

    if hRot.y < 0.5 and hRot.y > -0.5 then
        hRotY = -hRot.y*55
        model.T.setRot({hRotX, hRotY, 0})
    end

end

function colorDetection(stack)
    local tag = stack.getTag()
    if tag ~= nil and tag.display ~= nil then    
        return tag.display.color
    end
    return nil
end

function helmet()
    
    if succAct == false then

        if player.getEquipmentItem(6).getType() == "minecraft:leather_helmet" then
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(false)
            if(colorDetection(player.getEquipmentItem(6)) == 11546150) then
                model.T.Armor.leather.setEnabled(false)
                model.T.red.setEnabled(true)
            else
                model.T.Armor.leather.setEnabled(true)
                model.T.red.setEnabled(false)
            end
        elseif player.getEquipmentItem(6).getType() == "minecraft:chainmail_helmet" then
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(true)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(false)
            model.T.red.setEnabled(false)
        elseif player.getEquipmentItem(6).getType() == "minecraft:iron_helmet" then
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(true)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(false)
            model.T.red.setEnabled(false)
        elseif player.getEquipmentItem(6).getType() == "minecraft:golden_helmet" then
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(true)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(false)
            model.T.red.setEnabled(false)
        elseif player.getEquipmentItem(6).getType() == "minecraft:diamond_helmet" then
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(true)
            model.T.Armor.netherite.setEnabled(false)
            model.T.red.setEnabled(false)
        elseif player.getEquipmentItem(6).getType() == "minecraft:netherite_helmet" then
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(true)
            model.T.red.setEnabled(false)
        else
            model.T.Armor.leather.setEnabled(false)
            model.T.Armor.chainmail.setEnabled(false)
            model.T.Armor.iron.setEnabled(false)
            model.T.Armor.gold.setEnabled(false)
            model.T.Armor.diamond.setEnabled(false)
            model.T.Armor.netherite.setEnabled(false)
            model.T.red.setEnabled(false)
        end

    else
        
        model.T.Armor.leather.setEnabled(false)
        model.T.Armor.chainmail.setEnabled(false)
        model.T.Armor.iron.setEnabled(false)
        model.T.Armor.gold.setEnabled(false)
        model.T.Armor.diamond.setEnabled(false)
        model.T.Armor.netherite.setEnabled(false)
        model.T.red.setEnabled(false)

    end

end

function boots()

    local UVleatherB = {(0), (17/256)}
    local UVchainmailB = {(0), (34/256)}
    local UVironB = {(0), (51/256)}
    local UVgoldB = {(0), (68/256)}
    local UVdiamondB = {(0), (85/256)}
    local UVnetherB = {(22/256), (17/256)}

    if player.getEquipmentItem(3).getType() == "minecraft:leather_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVleatherB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVleatherB)
        model.KIRB_CROUCH.shoeR.setUV(UVleatherB)
        model.KIRB_CROUCH.shoeL.setUV(UVleatherB)
    elseif player.getEquipmentItem(3).getType() == "minecraft:chainmail_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVchainmailB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVchainmailB)
        model.KIRB_CROUCH.shoeR.setUV(UVchainmailB)
        model.KIRB_CROUCH.shoeL.setUV(UVchainmailB)
    elseif player.getEquipmentItem(3).getType() == "minecraft:iron_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVironB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVironB)
        model.KIRB_CROUCH.shoeR.setUV(UVironB)
        model.KIRB_CROUCH.shoeL.setUV(UVironB)
    elseif player.getEquipmentItem(3).getType() == "minecraft:golden_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVgoldB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVgoldB)
        model.KIRB_CROUCH.shoeR.setUV(UVgoldB)
        model.KIRB_CROUCH.shoeL.setUV(UVgoldB)
    elseif player.getEquipmentItem(3).getType() == "minecraft:diamond_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVdiamondB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVdiamondB)
        model.KIRB_CROUCH.shoeR.setUV(UVdiamondB)
        model.KIRB_CROUCH.shoeL.setUV(UVdiamondB)
    elseif player.getEquipmentItem(3).getType() == "minecraft:netherite_boots" then
        model.MIMIC_LEFT_LEG.shoe.setUV(UVnetherB)
        model.MIMIC_RIGHT_LEG.shoe.setUV(UVnetherB)
        model.KIRB_CROUCH.shoeR.setUV(UVnetherB)
        model.KIRB_CROUCH.shoeL.setUV(UVnetherB)
    else
        model.MIMIC_LEFT_LEG.shoe.setUV(default)
        model.MIMIC_RIGHT_LEG.shoe.setUV(default)
        model.KIRB_CROUCH.shoeR.setUV(default)
        model.KIRB_CROUCH.shoeL.setUV(default)
    end

end

function render(delta)

end

--Glint
function eHelmet()

    local tagE = player.getEquipmentItem(6).getTag()
    if tagE then
        if tagE.enchantments then
            model.T.Armor.leather.setShader("Glint")
            model.T.Armor.chainmail.setShader("Glint")
            model.T.Armor.iron.setShader("Glint")
            model.T.Armor.gold.setShader("Glint")
            model.T.Armor.diamond.setShader("Glint")
            model.T.Armor.netherite.setShader("Glint")
            model.T.red.setShader("Glint")
        else
            model.T.Armor.leather.setShader("None")
            model.T.Armor.chainmail.setShader("None")
            model.T.Armor.iron.setShader("None")
            model.T.Armor.gold.setShader("None")
            model.T.Armor.diamond.setShader("None")
            model.T.Armor.netherite.setShader("None")
            model.T.red.setShader("None")
        end
    else
        model.T.Armor.leather.setShader("None")
        model.T.Armor.chainmail.setShader("None")
        model.T.Armor.iron.setShader("None")
        model.T.Armor.gold.setShader("None")
        model.T.Armor.diamond.setShader("None")
        model.T.Armor.netherite.setShader("None")
        model.T.red.setShader("None")
    end

end

function eBoots()

    local tagE = player.getEquipmentItem(3).getTag()
    if tagE then
        if tagE.enchantments then
            model.MIMIC_LEFT_LEG.shoe.setShader("Glint")
            model.MIMIC_RIGHT_LEG.shoe.setShader("Glint")
            model.KIRB_CROUCH.shoeR.setShader("Glint")
            model.KIRB_CROUCH.shoeL.setShader("Glint")
        else
            model.MIMIC_LEFT_LEG.shoe.setShader("None")
            model.MIMIC_RIGHT_LEG.shoe.setShader("None")
            model.KIRB_CROUCH.shoeR.setShader("None")
            model.KIRB_CROUCH.shoeL.setShader("None")
        end
    else
        model.MIMIC_LEFT_LEG.shoe.setShader("None")
        model.MIMIC_RIGHT_LEG.shoe.setShader("None")
        model.KIRB_CROUCH.shoeR.setShader("None")
        model.KIRB_CROUCH.shoeL.setShader("None")
    end

end