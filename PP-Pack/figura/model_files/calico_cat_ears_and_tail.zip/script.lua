function player_init()
    tail_1 = model.TORSO.tail_1
    tail_2 = model.TORSO.tail_1.tail_2
    tail_3 = model.TORSO.tail_1.tail_2.tail_3
    tail_4 = model.TORSO.tail_1.tail_2.tail_3.tail_4
    tail_5 = model.TORSO.tail_1.tail_2.tail_3.tail_4.tail_5
    tail_6 = model.TORSO.tail_1.tail_2.tail_3.tail_4.tail_5.tail_6
    tail_7 = model.TORSO.tail_1.tail_2.tail_3.tail_4.tail_5.tail_6.tail_7
    tail_8 = model.TORSO.tail_1.tail_2.tail_3.tail_4.tail_5.tail_6.tail_7.tail_8
end

function tick()
    animation()
end

function animation()
    tail_1.setRot({((math.sin(world.getTime()/20)*6)) - 10 ,-((math.sin(world.getTime()/10)*6)),((math.sin(world.getTime()/20)*10))})
    tail_2.setRot({((math.sin(world.getTime()/18)*6)) - 15,-((math.sin(world.getTime()/10)*6)),0})
    tail_3.setRot({((math.sin(world.getTime()/16)*6)) - 15,-((math.sin(world.getTime()/10)*6)),((math.sin(world.getTime()/20)*10))})
    tail_4.setRot({((math.sin(world.getTime()/15)*6)) - 5,-((math.sin(world.getTime()/5)*6)),0})
    tail_5.setRot({((math.sin(world.getTime()/15)*6)) - 5 ,-((math.sin(world.getTime()/5)*6)),0})
    tail_6.setRot({((math.sin(world.getTime()/10)*6)) + 5,-((math.sin(world.getTime()/5)*6)),0})
    tail_7.setRot({((math.sin(world.getTime()/10)*6)) + 15,-((math.sin(world.getTime()/5)*6)),0})
    tail_8.setRot({((math.sin(world.getTime()/8)*6)) + 10,-((math.sin(world.getTime()/5)*6)),0})
end