-- turn off model

for key, value in pairs(vanilla_model) do
    value.setEnabled(false)
end

for key, value in pairs(armor_model) do
    value.setEnabled(false)
end

for key, value in pairs(elytra_model) do
    value.setEnabled(false)
end

--texture height and width

texture_height = 128
texture_width = 256


--armor table and function
armor = {
head = { model.base.Head.UpperHelmetLeft, model.base.Head.UpperHelmetRight, model.base.Head.MiddleHelmetLeft, model.base.Head.MiddleHelmetRight, model.base.Head.LowerHelmetLeft, model.base.Head.LowerHelmetRight },
chest = { model.base.Body.UpperChest, model.base.Body.MiddleChest,model.base.Body.LowerChest, model.base.RightArm.RightChestUpper, model.base.RightArm.RightChestLower, model.base.LeftArm.LeftChestUpper, model.base.LeftArm.LeftChestLower },
elytra = { model.base.Body.RIGHT_ELYTRA, model.base.Body.LEFT_ELYTRA },
legs = { model.base.Body.UpperLeggings, model.base.Body.MiddleLeggings, model.base.Body.LowerLeggings, model.base.LeftLeg.LeftLeggingsUpper, model.base.LeftLeg.LeftLeggingsLower, model.base.RightLeg.RightLeggingsUpper, model.base.RightLeg.RightLeggingsLower },
boots = { model.base.LeftLeg.LeftBootsUpper, model.base.LeftLeg.LeftBootsLower, model.base.RightLeg.RightBootsUpper, model.base.RightLeg.RightBootsLower }
}

armor.head[1].setEnabled(false)

--custom armor function
function update_armor(armor_table, x, table_vector)
    for key, value in pairs(armor_table) do
        value[x](table_vector)
    end
end

function tick()
    custom_armor()
end

function custom_armor()
    local boots = player.getEquipmentItem(3).getType()
    local legs = player.getEquipmentItem(4).getType()
    local chest = player.getEquipmentItem(5).getType()
    local head = player.getEquipmentItem(6).getType()
    --head
    update_armor(armor.head, "setColor", {1, 1, 1})
    if head == "minecraft:air" then
        update_armor(armor.head, "setEnabled", false)
    else
        update_armor(armor.head, "setEnabled", true)
    end

    if player.getEquipmentItem(6).hasGlint() then
        update_armor(armor.head, "setShader", "Glint")
    else
        update_armor(armor.head, "setShader", "None")
    end

    if head == "minecraft:turtle_helmet" then
        update_armor(armor.head, "setUV", {160/texture_width, 64/texture_height})
    elseif head == "minecraft:netherite_helmet" then
        update_armor(armor.head, "setUV", {128/texture_width, 32/texture_height})
    elseif head == "minecraft:diamond_helmet" then
        update_armor(armor.head, "setUV", {128/texture_width, 0})
    elseif head == "minecraft:iron_helmet" then
        update_armor(armor.head, "setUV", {0, 0})
    elseif head == "minecraft:golden_helmet" then
        update_armor(armor.head, "setUV", {0, 32/texture_height})
    elseif head == "minecraft:chainmail_helmet" then
        update_armor(armor.head, "setUV", {64/texture_width, 0})
    elseif head == "minecraft:leather_helmet" then
        update_armor(armor.head, "setUV", {64/texture_width, 32/texture_height})
        if player.getEquipmentItem(6).getTag() ~= nil and player.getEquipmentItem(6).getTag().display ~= nil and player.getEquipmentItem(6).getTag().display.color ~= nil then
            update_armor(armor.head, "setColor", vectors.intToRGB(player.getEquipmentItem(6).getTag().display.color))
        else
            update_armor(armor.head, "setColor", {134/255 , 82/255 , 53/255})
        end
    end

    --chest
    update_armor(armor.chest, "setColor", {1, 1, 1})
    if chest == "minecraft:air" or chest == "minecraft:elytra" then
        update_armor(armor.chest, "setEnabled", false)
    else
        update_armor(armor.chest, "setEnabled", true)
    end

    if player.getEquipmentItem(5).hasGlint() then
        update_armor(armor.chest, "setShader", "Glint")
        update_armor(armor.elytra, "setShader", "Glint")
    else
        update_armor(armor.chest, "setShader", "None")
        update_armor(armor.elytra, "setShader", "None")
    end

    if chest == "minecraft:netherite_chestplate" then
        update_armor(armor.chest, "setUV", {128/texture_width, 32/texture_height})
    elseif chest == "minecraft:diamond_chestplate" then
        update_armor(armor.chest, "setUV", {128/texture_width, 0})
    elseif chest == "minecraft:iron_chestplate" then
        update_armor(armor.chest, "setUV", {0, 0})
    elseif chest == "minecraft:golden_chestplate" then
        update_armor(armor.chest, "setUV", {0, 32/texture_height})
    elseif chest == "minecraft:chainmail_chestplate" then
        update_armor(armor.chest, "setUV", {64/texture_width, 0})
    elseif chest == "minecraft:leather_chestplate" then
        update_armor(armor.chest, "setUV", {64/texture_width, 32/texture_height})
        if player.getEquipmentItem(5).getTag() ~= nil and player.getEquipmentItem(5).getTag().display ~= nil and player.getEquipmentItem(5).getTag().display.color ~= nil then
            update_armor(armor.chest, "setColor", vectors.intToRGB(player.getEquipmentItem(5).getTag().display.color))
        else
            update_armor(armor.chest, "setColor", {134/255 , 82/255 , 53/255})
        end
    end

    --legs
    update_armor(armor.legs, "setColor", {1, 1, 1})
    if legs == "minecraft:air" or legs == "minecraft:elytra" then
        update_armor(armor.legs, "setEnabled", false)
    else
        update_armor(armor.legs, "setEnabled", true)
    end

    if player.getEquipmentItem(4).hasGlint() then
        update_armor(armor.legs, "setShader", "Glint")
    else
        update_armor(armor.legs, "setShader", "None")
    end

    if legs == "minecraft:netherite_leggings" then
        update_armor(armor.legs, "setUV", {128/texture_width, 32/texture_height})
    elseif legs == "minecraft:diamond_leggings" then
        update_armor(armor.legs, "setUV", {128/texture_width, 0})
    elseif legs == "minecraft:iron_leggings" then
        update_armor(armor.legs, "setUV", {0, 0})
    elseif legs == "minecraft:golden_leggings" then
        update_armor(armor.legs, "setUV", {0, 32/texture_height})
    elseif legs == "minecraft:chainmail_leggings" then
        update_armor(armor.legs, "setUV", {64/texture_width, 0})
    elseif legs == "minecraft:leather_leggings" then
        update_armor(armor.legs, "setUV", {64/texture_width, 32/texture_height})
        if player.getEquipmentItem(4).getTag() ~= nil and player.getEquipmentItem(4).getTag().display ~= nil and player.getEquipmentItem(4).getTag().display.color ~= nil then
            update_armor(armor.legs, "setColor", vectors.intToRGB(player.getEquipmentItem(4).getTag().display.color))
        else
            update_armor(armor.legs, "setColor", {134/255 , 82/255 , 53/255})
        end
    end

    --boots
    update_armor(armor.boots, "setColor", {1, 1, 1})
    if boots == "minecraft:air" or boots == "minecraft:elytra" then
        update_armor(armor.boots, "setEnabled", false)
    else
        update_armor(armor.boots, "setEnabled", true)
    end

    if player.getEquipmentItem(3).hasGlint() then
        update_armor(armor.boots, "setShader", "Glint")
    else
        update_armor(armor.boots, "setShader", "None")
    end

    if boots == "minecraft:netherite_boots" then
        update_armor(armor.boots, "setUV", {128/texture_width, 32/texture_height})
    elseif boots == "minecraft:diamond_boots" then
        update_armor(armor.boots, "setUV", {128/texture_width, 0})
    elseif boots == "minecraft:iron_boots" then
        update_armor(armor.boots, "setUV", {0, 0})
    elseif boots == "minecraft:golden_boots" then
        update_armor(armor.boots, "setUV", {0, 32/texture_height})
    elseif boots == "minecraft:chainmail_boots" then
        update_armor(armor.boots, "setUV", {64/texture_width, 0})
    elseif boots == "minecraft:leather_boots" then
        update_armor(armor.boots, "setUV", {64/texture_width, 32/texture_height})
        if player.getEquipmentItem(3).getTag() ~= nil and player.getEquipmentItem(3).getTag().display ~= nil and player.getEquipmentItem(3).getTag().display.color ~= nil then
            update_armor(armor.boots, "setColor", vectors.intToRGB(player.getEquipmentItem(3).getTag().display.color))
        else
            update_armor(armor.boots, "setColor", {134/255 , 82/255 , 53/255})
        end
    end
end

jointedLegs = true
jointedArms = true
alternativeLegs = false
alternativeArms = false
leanForward = true
bounceUpAndDown = true

for k,v in pairs(vanilla_model) do
    v.setEnabled(false)
end

function clamp(value,low,high)
    return math.min(math.max(value, low), high)
end

do
    local function lerp(a, b, x)
        return a + (b - a) * x
    end
    local function lerp_3d(a, b, x)
        return {lerp(a[1],b[1],x),lerp(a[2],b[2],x),lerp(a[3],b[3],x)}
    end
    function new_lerped_property(part)
        local ret = {}
        ret.prev_pos = {0,0,0}
        ret.curr_pos = {0,0,0}
        ret.enab_pos = false
        ret.prev_rot = {0,0,0}
        ret.curr_rot = {0,0,0}
        ret.enab_rot = false
        ret.prev_sca = {1,1,1}
        ret.curr_sca = {1,1,1}
        ret.enab_sca = false
        ret.prev_uv = {0,0,0}
        ret.curr_uv = {0,0,0}
        ret.enab_uv = false
        ret.prev_col = {1,1,1}
        ret.curr_col = {1,1,1}
        ret.enab_col = false
        ret.prev_opa = 1
        ret.curr_opa = 1
        ret.enab_opa = false
        function tick()
            ret.prev_pos = ret.curr_pos
            ret.prev_rot = ret.curr_rot
            ret.prev_sca = ret.curr_sca
            ret.prev_uv = ret.curr_uv
            ret.prev_col = ret.curr_col
            ret.prev_opa = ret.curr_opa
        end
        function render(delta)
            if ret.enab_pos then part.setPos(lerp_3d(ret.prev_pos,ret.curr_pos,delta)) end
            if ret.enab_rot then part.setRot(lerp_3d(ret.prev_rot,ret.curr_rot,delta)) end
            if ret.enab_sca then part.setScale(lerp_3d(ret.prev_sca,ret.curr_sca,delta)) end
            if ret.enab_uv then part.setUV(lerp_3d(ret.prev_uv,ret.curr_uv,delta)) end
            if ret.enab_col then part.setColor(lerp_3d(ret.prev_col,ret.curr_col,delta)) end
            if ret.enab_opa then part.setOpacity(lerp(ret.prev_opa,ret.curr_opa,delta)) end
        end
        local function setPos(pos)
            ret.enab_pos = true
            ret.curr_pos = pos
        end
        local function setRot(rot)
            ret.enab_rot = true
            ret.curr_rot = rot
        end
        local function setScale(scale)
            ret.enab_scale = true
            ret.curr_sca = scale
        end
        local function setUV(uv)
            ret.enab_uv = true
            ret.curr_uv = uv
        end
        local function setColor(color)
            ret.enab_col = true
            ret.curr_col = color
        end
        local function setOpacity(opacity)
            ret.enab_opa = true
            ret.curr_opa = opacity
        end
        ret.setPos = setPos
        ret.setRot = setRot
        ret.setScale = setScale
        ret.setUV = setUV
        ret.setColor = setColor
        ret.setOpacity = setOpacity
        return ret
    end
end

lowerLeftLeg = new_lerped_property(model.base.LeftLeg.LeftLegLower)
lowerRightLeg = new_lerped_property(model.base.RightLeg.RightLegLower)
lowerLeftArm = new_lerped_property(model.base.LeftArm.LeftArmLower)
lowerRightArm = new_lerped_property(model.base.RightArm.RightArmLower)

lowerLeftLeggings = new_lerped_property(model.base.LeftLeg.LeftLeggingsLower)
lowerRightLeggings = new_lerped_property(model.base.RightLeg.RightLeggingsLower)
lowerLeftBoots = new_lerped_property(model.base.LeftLeg.LeftBootsLower)
lowerRightBoots = new_lerped_property(model.base.RightLeg.RightBootsLower)

lowerLeftArmChest = new_lerped_property(model.base.LeftArm.LeftChestLower)
lowerRightArmChest = new_lerped_property(model.base.RightArm.RightChestLower)

modelplayer = new_lerped_property(model.base)

RR = 0
_RR = 0
LL = 0
_LL = 0
RA = 0
_RA = 0
LA = 0
_LA = 0
pos = nil
_pos = nil
function player_init()
    pos = player.getPos()
    _pos = player.getPos()
end

function tick()
    if leanForward then
        _pos = pos
        pos = player.getPos()
        local speed = _pos-pos
        speed = vectors.of({speed.x, 0, speed.z}).getLength()*60
        modelplayer.setRot({-speed,0,0})
    end
    if jointedArms then
        _RA = RA
        _LA = LA
        RA = (vanilla_model.RIGHT_ARM.getOriginRot().x*57.3)*1.5
        LA = (vanilla_model.LEFT_ARM.getOriginRot().x*57.3)*1.5
        if alternativeArms then
            lowerRightArm.setRot({math.abs(_RA-RA),0,0})
            lowerLeftArm.setRot({math.abs(_LA-LA),0,0})

            lowerRightArmChest.setRot({math.abs(_RA-RA),0,0})
            lowerLeftArmChest.setRot({math.abs(_LA-LA),0,0})
        else
            lowerRightArm.setRot({clamp(_RA-RA, 0, 69),0,0})
            lowerLeftArm.setRot({clamp(_LA-LA, 0, 69),0,0})

            lowerRightArmChest.setRot({clamp(_RA-RA, 0, 69),0,0})
            lowerLeftArmChest.setRot({clamp(_LA-LA, 0, 69),0,0})
        end
    end
    if jointedLegs then
        _RR = RR
        _LL = LL
        RR = (vanilla_model.RIGHT_LEG.getOriginRot().x*57.3)*1.5
        LL = (vanilla_model.LEFT_LEG.getOriginRot().x*57.3)*1.5
        if alternativeLegs then
            lowerRightLeg.setRot({-math.abs(RR-_RR),0,0})
            lowerLeftLeg.setRot({-math.abs(LL-_LL),0,0})

            lowerRightLeggings.setRot({-math.abs(RR-_RR),0,0})
            lowerLeftLeggings.setRot({-math.abs(LL-_LL),0,0})

            lowerRightBoots.setRot({-math.abs(RR-_RR),0,0})
            lowerLeftBoots.setRot({-math.abs(LL-_LL),0,0})
        else
            lowerRightLeg.setRot({clamp(RR-_RR, -69, 0),0,0})
            lowerLeftLeg.setRot({clamp(LL-_LL, -69, 0),0,0})

            lowerRightLeggings.setRot({clamp(RR-_RR, -69, 0),0,0})
            lowerLeftLeggings.setRot({clamp(LL-_LL, -69, 0),0,0})

            lowerRightBoots.setRot({clamp(RR-_RR, -69, 0),0,0})
            lowerLeftBoots.setRot({clamp(LL-_LL, -69, 0),0,0})
        end
    end
    if bounceUpAndDown then
        modelplayer.setPos({0,math.abs(vanilla_model.RIGHT_LEG.getOriginRot().x*1.5),0})
    end
end


